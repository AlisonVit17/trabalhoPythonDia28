#Pelo pouco que consegui abstrair, o QStack é para usar o current

from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication

def corre():
    print('Run')


app = QApplication([])
window = loadUi('untitled.ui')
nome = window.email.text()
window.show()
app.exec()
print(nome)

string = 'alison@gmail'

strlista = string.split('@')

try:

    strlista[2]
except:

    print(strlista, string)
