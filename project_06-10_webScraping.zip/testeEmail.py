import email.message
import smtplib
import os

def enviar_email():

    menssagemEmail = 'Alsu'
    msg = email.message.Message()
    msg['From'] = 'alissonmarqueshm30@gmail.com'
    msg['Subject'] = 'TRABALHO DE PYTHON'
    msg['To'] = 'alissonhmarques@gmail.com'


    msg.add_header('Content-Type', 'text/html')
    msg.set_payload(menssagemEmail)
    password = 'thrcsphizixlgcup'

    s = smtplib.SMTP('smtp.gmail.com: 587')
    s.starttls()
    s.login(msg['From'], password)
    s.sendmail(msg['From'], msg['To'], msg.as_string().encode('utf-8'))


for i in range(4):
    enviar_email()
